
<script src="{{asset('admin_src/plugins/jquery/jquery.min.js')}}"></script>
<script src="{{asset('admin_src/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('admin_src/dist/js/adminlte.min.js')}}"></script>
