

<link rel="stylesheet" type="text/css" href="{{asset('admin_src/plugins/fontawesome-free/css/all.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('admin_src/dist/css/adminlte.min.css')}}">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
